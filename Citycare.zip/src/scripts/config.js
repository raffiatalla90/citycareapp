const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  TOKEN_KEY: 'story_app_token',
};

export default CONFIG;
